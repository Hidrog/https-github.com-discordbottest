// @flow

import React from 'react';
import Constants from '../Constants';

export default (): React.Element => (
  <object data={Constants.Image.AIRHORN_COUNTER} />
);
