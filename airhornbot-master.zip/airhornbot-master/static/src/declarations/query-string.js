declare module 'query-string' {
  declare function parse(str: string): {[key: string]: any};
}
