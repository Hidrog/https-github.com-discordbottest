declare module 'detect-browser' {
  declare var name: string;
  declare var version: string;
}
