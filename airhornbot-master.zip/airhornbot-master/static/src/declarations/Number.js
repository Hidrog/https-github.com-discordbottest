declare class Number {
  static parseInt(value: string | number): number;
}
