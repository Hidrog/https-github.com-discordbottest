declare module 'numeral' {
  declare function exports(num: number): {
    format: (format: string) => string
  };
}
