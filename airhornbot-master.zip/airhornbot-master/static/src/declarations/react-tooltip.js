declare module 'react-tooltip' {
  declare var exports: ReactClass;
}
